خطوات تحويل المشروع إلى IPA من ويندوز (مجانًا)
1) أنشئ حسابًا على github.com ثم مستودعًا جديدًا (New repository) باسم hisn.
2) ارفع كل محتويات هذا المجلد إلى المستودع (زر Add file > Upload files)، مع مجلد .github كما هو.
   إن لم يظهر مجلد .github لأنه مخفي، أنشئ الملف يدويًا: Add file > Create new file
   واكتب الاسم  .github/workflows/ios.yml  والصق محتواه.
3) افتح تبويب Actions > Build IPA > Run workflow، وانتظر نحو 10 دقائق.
4) من صفحة التشغيل نزّل الملف HisnAlMuslim-ipa (داخله HisnAlMuslim.ipa).
5) ثبّته على الآيفون: ثبّت برنامج Sideloadly على ويندوز (ويحتاج iTunes و iCloud من موقع Apple)،
   وصّل الآيفون بالكابل، اسحب ملف IPA، وأدخل Apple ID، ثم اضغط Start.
6) على الآيفون: الإعدادات > عام > VPN وإدارة الجهاز > ثق بحسابك.
ملاحظة: بحساب Apple المجاني يعمل التطبيق 7 أيام ثم يُعاد تثبيته. للتثبيت الدائم أو App Store يلزم حساب Developer مدفوع.
